<?php
echo 'Nama  : ' . $_POST['nama'] . '<br/>';
echo 'Email : ' . $_POST['email'];
echo '<pre>'; print_r($_POST);